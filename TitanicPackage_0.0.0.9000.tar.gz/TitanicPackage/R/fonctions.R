#' Calculer le taux de survie selon une variable
#'
#' @param donnees Tableau contenant la colonne survived (yes ou no).
#' @param variable Nom de la variable de regroupement entre guillemets.
#' @return Tableau des taux de survie en pourcentage par groupe.
#' @export
#' @examples
#' d <- data.frame(survived = c("yes", "no"), sex = c("female", "male"))
#' taux_survie(d, "sex")
taux_survie <- function(donnees, variable) {
  resultat <- stats::aggregate(
    x = list(taux_survie_pct = 100 * (donnees$survived == "yes")),
    by = list(groupe = donnees[[variable]]),
    FUN = mean,
    na.rm = TRUE
  )

  resultat$taux_survie_pct <- round(resultat$taux_survie_pct, 1)
  return(resultat)
}

